package com.sellerservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sellerservice.entity.Seller;
import com.sellerservice.service.Iseller;

@RestController
public class SellerController {
	
	@Autowired
	private Iseller service;
	
	@RequestMapping("/getAll")
	public List<Seller> getAll() 
    {
		  return service.getAll(); 
    } 
	
	@RequestMapping(value="/Add/seller",method=RequestMethod.POST)
	public Seller add(@RequestBody Seller seller) 
	{
		return service.add(seller);
	}
	
	@RequestMapping(value="/getUser/{id}" , method=RequestMethod.GET)
	public Seller getSeller(@PathVariable("id") int sellerid) {
		return service.getUser(sellerid);
	}
	
	@RequestMapping(value="/update/Seller/{id}",method=RequestMethod.PUT)
	public Seller updateSeller(@RequestBody Seller seller,@PathVariable("id") int sellerid) 
	{
		return service.updateSeller(seller,sellerid);
	}

}
