import { Component, OnInit, Input } from '@angular/core';
import { Item } from '../customer';
import {CustomerService} from '../customer.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  @Input() item: Item;

  constructor() { }

  ngOnInit() {
  }
}
