package com.ecommerce.seller.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.seller.model.ItemInventory;
import com.ecommerce.seller.model.SearchItem;
import com.ecommerce.seller.model.Seller;
import com.ecommerce.seller.repository.ItemRepository;
import com.ecommerce.seller.repository.SellerRepository;

@Service
public class ItemInventoryService {
	
	@Autowired
	private SellerRepository sellerRepository;
	
	@Autowired
	private ItemRepository itemRepository;
	
	
	
	public ItemInventory addItems(ItemInventory item, Integer sellerId) {
		Optional<Seller> optionalSeller = sellerRepository.findById(sellerId);
		item.setSellerId(optionalSeller.get().getSellerId());
		return itemRepository.save(item);
	}
	
	
	public List<ItemInventory> getAllItems(Integer sellerId){
		return itemRepository.findBySellerId(sellerId);
	}
	
	
	public void deleteItem(Integer sellerId, Integer itemId) {
		itemRepository.deleteItemById(sellerId,itemId);
	}
	
	
	public ItemInventory updateItem(ItemInventory item, Integer itemId) {
		Optional<ItemInventory> optionalItem = itemRepository.findById(itemId);
		if(optionalItem.isPresent()) {
			ItemInventory updatedItem = optionalItem.get();
			updatedItem.setItemStockNumber(item.getItemStockNumber());
			updatedItem.setCategory(item.getCategory());
			updatedItem.setItemDescription(item.getItemDescription());
			//updatedItem.setSellerId(item.getSellerId());
			updatedItem.setSubcategory(item.getSubcategory());
			updatedItem.setItemName(item.getItemName());
			updatedItem.setItemRemarks(item.getItemRemarks());
			
			return itemRepository.save(updatedItem);
		}
		
		return null;
	}
	
	
	public List<ItemInventory> searchItem(SearchItem item) {
		return itemRepository.findItem(item.getSearchString().toLowerCase());
	}

}
