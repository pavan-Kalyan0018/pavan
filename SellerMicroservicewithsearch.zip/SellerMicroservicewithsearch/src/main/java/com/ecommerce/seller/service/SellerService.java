package com.ecommerce.seller.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.seller.model.Seller;
import com.ecommerce.seller.repository.SellerRepository;

@Service
public class SellerService {
	
	
	
	@Autowired
	private SellerRepository sellerRepository;
	
	public Seller addSeller(Seller seller) {
		
		return sellerRepository.save(seller);
	}

}
