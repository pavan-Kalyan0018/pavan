package com.ecommerce.seller.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name = "item_table_seller")
public class ItemInventory implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "item_id")
	private Integer itemId;
	
	private Integer sellerId;
	
	private Integer category;
	
	private Integer subcategory;
	@Column
	private Double itemCost;
	@Column
	private String itemName;
	@Column
	private String itemDescription;
	@Column
	private Integer itemStockNumber;
	@Column
	private String itemRemarks;
	
	public ItemInventory() {
		// TODO Auto-generated constructor stub
	}

	
	
	
	public Integer getItemId() {
		return itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}

	
	public Double getItemCost() {
		return itemCost;
	}

	public void setItemCost(Double itemCost) {
		this.itemCost = itemCost;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public Integer getItemStockNumber() {
		return itemStockNumber;
	}

	public void setItemStockNumber(Integer itemStockNumber) {
		this.itemStockNumber = itemStockNumber;
	}

	public String getItemRemarks() {
		return itemRemarks;
	}

	public void setItemRemarks(String itemRemarks) {
		this.itemRemarks = itemRemarks;
	}




	public ItemInventory(Integer itemId, Integer sellerId, Integer category, Integer subcategory, Double itemCost,
			String itemName, String itemDescription, Integer itemStockNumber, String itemRemarks) {
		super();
		this.itemId = itemId;
		this.sellerId = sellerId;
		this.category = category;
		this.subcategory = subcategory;
		this.itemCost = itemCost;
		this.itemName = itemName;
		this.itemDescription = itemDescription;
		this.itemStockNumber = itemStockNumber;
		this.itemRemarks = itemRemarks;
	}




	public Integer getSellerId() {
		return sellerId;
	}




	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}




	public Integer getCategory() {
		return category;
	}




	public void setCategory(Integer category) {
		this.category = category;
	}




	public Integer getSubcategory() {
		return subcategory;
	}




	public void setSubcategory(Integer subcategory) {
		this.subcategory = subcategory;
	}
	
	
	
	
	

}
