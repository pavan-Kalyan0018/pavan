package com.ecommerce.seller.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.seller.model.ItemInventory;
import com.ecommerce.seller.model.SearchItem;
import com.ecommerce.seller.service.ItemInventoryService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/item")
public class ItemInventoryController {
	
	@Autowired
	private ItemInventoryService itemService;
	
	@PostMapping(value = "/{sellerid}/additem",produces = "application/json")
	public ItemInventory addItem(@RequestBody ItemInventory item, @PathVariable("sellerid") Integer sellerId) {
		return itemService.addItems(item, sellerId);
	}
	
	@GetMapping(value = "/{sellerid}/getAll")
	public List<ItemInventory> getAllItems(@PathVariable("sellerid") Integer sellerId) {
		return itemService.getAllItems(sellerId);
	}
	
	@PutMapping(value = "/{itemid}/updateitem", produces = "application/json")
	public ItemInventory updateItem(@RequestBody ItemInventory item, @PathVariable("itemid") Integer itemId) {
		return itemService.updateItem(item, itemId);
	}
	
	@DeleteMapping(value = "/{sellerid}/{itemid}/deleteitem")
	public void deleteItem(@PathVariable("sellerid") Integer sellerId, @PathVariable("itemid") Integer itemId) {
		itemService.deleteItem(sellerId, itemId);
	}
	
	@PostMapping(value = "/searchitem", produces = "application/json")
	public List<ItemInventory> searchItems(@RequestBody SearchItem item) {
		return itemService.searchItem(item);
	}
}
